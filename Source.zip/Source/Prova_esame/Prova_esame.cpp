// Copyright Epic Games, Inc. All Rights Reserved.

#include "Prova_esame.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, Prova_esame, "Prova_esame" );
 