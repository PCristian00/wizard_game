// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "Ground_without_effect.h"
#include "Ground_with_effect.h"
#include "Wall_with_door.h"
#include "Wall_without_door.h"
#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "RoomGenerator.generated.h"

UCLASS()
class PROVA_ESAME_API ARoomGenerator : public AActor
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	ARoomGenerator();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

	static const int tilesPerFloor = 7;
	int floorTilesTypes[tilesPerFloor][tilesPerFloor] = {0};

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;


	void DetermineFloorTilesType(int roomValue) {
		int floorCentre = (tilesPerFloor - 1) / 2;
		int initialRoomValue = roomValue;

		floorTilesTypes[floorCentre][floorCentre] = -2;

		if (roomValue % 2 == 1) {
			for (int tilePosY = floorCentre + 1; tilePosY < tilesPerFloor; tilePosY++) {
				floorTilesTypes[floorCentre][tilePosY] = -2;
			}
		}
		roomValue = roomValue / 2;

		if (roomValue % 2 == 1) {
			for (int tilePosX = 0; tilePosX < floorCentre; tilePosX++) {
				floorTilesTypes[tilePosX][floorCentre] = -2;
			}
		}
		roomValue = roomValue / 2;

		if (roomValue % 2 == 1) {
			for (int tilePosY = 0; tilePosY < floorCentre; tilePosY++) {
				floorTilesTypes[floorCentre][tilePosY] = -2;
			}
		}
		roomValue = roomValue / 2;

		if (roomValue == 1) {
			for (int tilePosX = floorCentre + 1; tilePosX < tilesPerFloor; tilePosX++) {
				floorTilesTypes[tilePosX][floorCentre] = -2;
			}
		}
		
		/*
		UE_LOG(LogTemp, Display, TEXT("--------------------"));
		for (int i = 0; i < tilesPerFloor; i++) {
			UE_LOG(LogTemp, Display, TEXT("%d %d %d %d %d %d %d"), floorTilesTypes[i][0], floorTilesTypes[i][1], floorTilesTypes[i][2], floorTilesTypes[i][3], floorTilesTypes[i][4], floorTilesTypes[i][5], floorTilesTypes[i][6]);
		}
		UE_LOG(LogTemp, Display, TEXT(" "));
		*/

		BuildWalls(initialRoomValue);
	}


	// Spawna le mura attorno ad ogni stanza tenendo conto del numero e della posizione delle porte
	void BuildWalls(int roomValue) {
		FActorSpawnParameters spawnParams;
		FVector spawnPos = GetActorLocation();
		int wallRotation = 0;

		for (double angle = 0.0; angle <= 1.5; angle += 0.5) {
			if (roomValue % 2 == 1) {
				GetWorld()->SpawnActor<AWall_with_door>(spawnPos + 375 * FVector(round(cos(angle * PI)), -round(sin(angle * PI)), 0), FRotator(0, wallRotation, 0), spawnParams);
			}
			else {
				GetWorld()->SpawnActor<AWall_without_door>(spawnPos + 375 * FVector(round(cos(angle * PI)), -round(sin(angle * PI)), 0), FRotator(0, wallRotation, 0), spawnParams);
			}
			roomValue = roomValue / 2;
			wallRotation = wallRotation - 90;
		}

		BuildFloor();
	}


	// Spawna le tiles che compongono il pavimento (alcune tiles applicano un effetto al giocatore, altre no)
	void BuildFloor() {
		FActorSpawnParameters spawnParams;
		FVector spawnPos = GetActorLocation();
		int tilesOffset = (tilesPerFloor - 1) / 2;
		int tilesPosX, tilesPosY;

		for (int row = 0; row < tilesPerFloor; row++) {
			for (int col = 0; col < tilesPerFloor; col++) {
				tilesPosX = (col - tilesOffset) * 100;
				tilesPosY = (row - tilesOffset) * 100;

				if (floorTilesTypes[row][col] == 0) {
					GetWorld()->SpawnActor<AGround_with_effect>(spawnPos + FVector(tilesPosX, tilesPosY, -150), FRotator(0, 0, 0), spawnParams);
				}
				else {
					GetWorld()->SpawnActor<AGround_without_effect>(spawnPos + FVector(tilesPosX, tilesPosY, -150), FRotator(0, 0, 0), spawnParams);
				}
			}
		}
	}


	UPROPERTY()
	USceneComponent* Root;
};
